import { useState } from "react";
import { NextNav } from "./components/loyalty/NextNav";
import { LoyaltyHero, UserState } from "./components/loyalty/LoyaltyHero";
import { LoyaltyBenefits } from "./components/loyalty/LoyaltyBenefits";
import { EarnDetail } from "./components/loyalty/EarnDetail";
import { LoyaltyFooter } from "./components/loyalty/LoyaltyFooter";
import { SignInModal } from "./components/loyalty/SignInModal";
import { ProgrammeOverview } from "./components/loyalty/ProgrammeOverview";
import { DataUseStatement } from "./components/loyalty/DataUseStatement";
import { EnrolmentForm } from "./components/loyalty/EnrolmentForm";
import { AccountExists } from "./components/loyalty/AccountExists";
import { ConfirmationQR } from "./components/loyalty/ConfirmationQR";
import { LoyaltyDashboard } from "./components/loyalty/LoyaltyDashboard";

type Screen = "1.0" | "2.0" | "3.0" | "4.0" | "Er.1" | "5.0" | "6.0";

interface FlowState {
  marketingOptIn: boolean;
  physicalCard: boolean;
  duplicateEmail: string;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("1.0");
  const [userState, setUserState] = useState<UserState>("anonymous");
  const [userEmail, setUserEmail] = useState<string | undefined>(undefined);
  const [memberName, setMemberName] = useState("Clara M.");
  const [showSignIn, setShowSignIn] = useState(false);
  const [showDevPanel, setShowDevPanel] = useState(false);
  const [flowState, setFlowState] = useState<FlowState>({ marketingOptIn: false, physicalCard: false, duplicateEmail: "" });

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  const navigate = (to: Screen) => {
    setScreen(to);
    scrollToTop();
  };

  // ── Screen 1.0 handlers ──────────────────────────────────────────────────
  const handleHeroJoin = () => {
    if (userState === "member") {
      navigate("6.0");
    } else if (userState === "no-loyalty") {
      // Pre-populated user skips to Data Use Statement (3.0)
      navigate("3.0");
    } else {
      navigate("2.0");
    }
  };

  const handleSignedIn = (email: string) => {
    setUserEmail(email);
    // Derive a display name from email prefix
    const prefix = email.split("@")[0].replace(/[._]/g, " ");
    setMemberName(prefix.replace(/\b\w/g, (c) => c.toUpperCase()) + " M.");
    setShowSignIn(false);
    setUserState("no-loyalty");
  };

  // ── Screen 4.0 handlers ──────────────────────────────────────────────────
  const handleEnrolSubmit = (email: string) => {
    const prefix = email.split("@")[0].replace(/[._]/g, " ");
    setMemberName(prefix.replace(/\b\w/g, (c) => c.toUpperCase()) + " M.");
    setUserEmail(email);
    navigate("5.0");
  };

  const handleAccountExists = (email: string) => {
    setFlowState((s) => ({ ...s, duplicateEmail: email }));
    navigate("Er.1");
  };

  // ── Screen Er.1 handlers ─────────────────────────────────────────────────
  const handleMerge = () => {
    // In production: open merge flow; here we simulate success and continue to 5.0
    navigate("5.0");
  };

  // ── Render ───────────────────────────────────────────────────────────────
  const renderScreen = () => {
    switch (screen) {
      case "1.0":
        return (
          <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
            <NextNav
              onSignInClick={() => setShowSignIn(true)}
              isSignedIn={userState !== "anonymous"}
            />
            <main style={{ flex: 1 }}>
              <LoyaltyHero
                userState={userState}
                userEmail={userEmail}
                onJoin={handleHeroJoin}
                onSignIn={() => setShowSignIn(true)}
              />
              <LoyaltyBenefits />
              <EarnDetail />

              {/* Bottom CTA strip — anonymous only */}
              {userState === "anonymous" && (
                <section style={{ backgroundColor: "#FFFFFF", borderTop: "1px solid #E5E5E5", padding: "64px 24px", textAlign: "center" }}>
                  <div style={{ maxWidth: 560, margin: "0 auto" }}>
                    <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#007A7A", textTransform: "uppercase", letterSpacing: "0.16em", marginBottom: 16 }}>
                      JOIN TODAY — IT'S FREE
                    </p>
                    <h2 style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: "clamp(24px,3vw,36px)", color: "#000000", marginBottom: 12, letterSpacing: "-0.01em", lineHeight: 1.2 }}>
                      Ready to start earning?
                    </h2>
                    <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 17, color: "#555555", lineHeight: 1.65, marginBottom: 36 }}>
                      No credit account needed. Join in under two minutes and earn points on your very next purchase.
                    </p>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "center" }}>
                      <button
                        onClick={() => navigate("2.0")}
                        style={{ backgroundColor: "#000000", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", padding: "0 36px", height: 52, borderRadius: 4, border: "none", cursor: "pointer" }}
                      >
                        Join the Loyalty Programme
                      </button>
                      <button
                        onClick={() => setShowSignIn(true)}
                        style={{ backgroundColor: "transparent", color: "#000000", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", padding: "0 36px", height: 52, borderRadius: 4, border: "1px solid #000000", cursor: "pointer" }}
                      >
                        Already have an account?
                      </button>
                    </div>
                  </div>
                </section>
              )}
            </main>
            <LoyaltyFooter />

            {showSignIn && (
              <SignInModal
                onClose={() => setShowSignIn(false)}
                onSignedIn={handleSignedIn}
              />
            )}
          </div>
        );

      case "2.0":
        return (
          <>
            <div style={{ position: "sticky", top: 0, zIndex: 200, backgroundColor: "#000000" }}>
              <NextNav onSignInClick={() => setShowSignIn(true)} isSignedIn={userState !== "anonymous"} />
            </div>
            <ProgrammeOverview
              onBack={() => navigate("1.0")}
              onContinue={() => navigate("3.0")}
            />
          </>
        );

      case "3.0":
        return (
          <>
            <div style={{ position: "sticky", top: 0, zIndex: 200, backgroundColor: "#000000" }}>
              <NextNav onSignInClick={() => setShowSignIn(true)} isSignedIn={userState !== "anonymous"} />
            </div>
            <DataUseStatement
              onBack={() => navigate("2.0")}
              onContinue={(marketing) => {
                setFlowState((s) => ({ ...s, marketingOptIn: marketing }));
                navigate("4.0");
              }}
              isNextPayUser={userState === "no-loyalty" && userEmail?.includes("nextpay")}
            />
          </>
        );

      case "4.0":
        return (
          <>
            <div style={{ position: "sticky", top: 0, zIndex: 200, backgroundColor: "#000000" }}>
              <NextNav onSignInClick={() => setShowSignIn(true)} isSignedIn={userState !== "anonymous"} />
            </div>
            <EnrolmentForm
              onBack={() => navigate("3.0")}
              onSubmit={handleEnrolSubmit}
              onAccountExists={handleAccountExists}
              prefillEmail={userState === "no-loyalty" ? userEmail : undefined}
              prefillLinkAccount={userState === "no-loyalty"}
            />
          </>
        );

      case "Er.1":
        return (
          <>
            <div style={{ position: "sticky", top: 0, zIndex: 200, backgroundColor: "#000000" }}>
              <NextNav onSignInClick={() => setShowSignIn(true)} isSignedIn={userState !== "anonymous"} />
            </div>
            <AccountExists
              email={flowState.duplicateEmail}
              onSignIn={() => {
                setShowSignIn(true);
                // After sign in, continue to 5.0
              }}
              onMerge={handleMerge}
              onUseDifferentEmail={() => navigate("4.0")}
            />
          </>
        );

      case "5.0":
        return (
          <>
            <div style={{ position: "sticky", top: 0, zIndex: 200, backgroundColor: "#000000" }}>
              <NextNav onSignInClick={() => setShowSignIn(true)} isSignedIn />
            </div>
            <ConfirmationQR
              memberName={memberName}
              requestedPhysicalCard={flowState.physicalCard}
              onDashboard={() => {
                setUserState("member");
                navigate("6.0");
              }}
            />
          </>
        );

      case "6.0":
        return (
          <>
            <div style={{ position: "sticky", top: 0, zIndex: 200, backgroundColor: "#000000" }}>
              <NextNav onSignInClick={() => {}} isSignedIn />
            </div>
            <LoyaltyDashboard
              memberName={memberName}
              points={100}
              onSignOut={() => {
                setUserState("anonymous");
                setUserEmail(undefined);
                navigate("1.0");
              }}
            />
          </>
        );

      default:
        return null;
    }
  };

  return (
    <div style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif" }}>
      {renderScreen()}

      {/* Dev state switcher */}
      <div style={{ position: "fixed", bottom: 16, right: 16, zIndex: 9999 }}>
        <button
          onClick={() => setShowDevPanel(!showDevPanel)}
          style={{ backgroundColor: "#007A7A", color: "#FFFFFF", fontFamily: "'Barlow',monospace", fontSize: 10, padding: "6px 12px", borderRadius: 20, border: "none", cursor: "pointer", letterSpacing: "0.08em", fontWeight: 600 }}
        >
          DEV · {screen}
        </button>

        {showDevPanel && (
          <div style={{ position: "absolute", bottom: 44, right: 0, backgroundColor: "#FFFFFF", border: "1px solid #E5E5E5", borderRadius: 8, padding: "14px 16px", boxShadow: "0 8px 24px rgba(0,0,0,0.14)", minWidth: 240 }}>
            <p style={{ fontFamily: "'Barlow',monospace", fontSize: 10, color: "#999999", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 10 }}>
              Jump to screen
            </p>
            {([
              { id: "1.0", label: "1.0 — Loyalty Landing" },
              { id: "2.0", label: "2.0 — Programme Overview" },
              { id: "3.0", label: "3.0 — Data Use Statement" },
              { id: "4.0", label: "4.0 — Enrolment Form" },
              { id: "Er.1", label: "Er.1 — Account Exists" },
              { id: "5.0", label: "5.0 — Confirmation & QR" },
              { id: "6.0", label: "6.0 — Loyalty Dashboard" },
            ] as { id: Screen; label: string }[]).map((opt) => (
              <button
                key={opt.id}
                onClick={() => {
                  if (opt.id === "Er.1") setFlowState((s) => ({ ...s, duplicateEmail: "existing@next.co.uk" }));
                  if (opt.id === "6.0") setUserState("member");
                  navigate(opt.id);
                  setShowDevPanel(false);
                }}
                style={{
                  display: "block",
                  width: "100%",
                  textAlign: "left",
                  padding: "7px 10px",
                  marginBottom: 3,
                  borderRadius: 4,
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif",
                  fontSize: 12,
                  backgroundColor: screen === opt.id ? "#000000" : "transparent",
                  color: screen === opt.id ? "#FFFFFF" : "#000000",
                }}
                onMouseEnter={(e) => { if (screen !== opt.id) e.currentTarget.style.backgroundColor = "#F2F2F2"; }}
                onMouseLeave={(e) => { if (screen !== opt.id) e.currentTarget.style.backgroundColor = "transparent"; }}
              >
                {opt.label}
              </button>
            ))}

            <div style={{ height: 1, backgroundColor: "#E5E5E5", margin: "10px 0" }} />
            <p style={{ fontFamily: "'Barlow',monospace", fontSize: 10, color: "#999999", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}>
              Simulate user state
            </p>
            {([
              { value: "anonymous", label: "Anonymous visitor" },
              { value: "no-loyalty", label: "Signed in, no loyalty" },
              { value: "member", label: "Loyalty member" },
            ] as { value: UserState; label: string }[]).map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  setUserState(opt.value);
                  if (opt.value === "no-loyalty") setUserEmail("j.smith@email.com");
                  if (opt.value === "anonymous") setUserEmail(undefined);
                  setShowDevPanel(false);
                }}
                style={{
                  display: "block",
                  width: "100%",
                  textAlign: "left",
                  padding: "7px 10px",
                  marginBottom: 3,
                  borderRadius: 4,
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif",
                  fontSize: 12,
                  backgroundColor: userState === opt.value ? "#007A7A" : "transparent",
                  color: userState === opt.value ? "#FFFFFF" : "#000000",
                }}
                onMouseEnter={(e) => { if (userState !== opt.value) e.currentTarget.style.backgroundColor = "#F2F2F2"; }}
                onMouseLeave={(e) => { if (userState !== opt.value) e.currentTarget.style.backgroundColor = "transparent"; }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
