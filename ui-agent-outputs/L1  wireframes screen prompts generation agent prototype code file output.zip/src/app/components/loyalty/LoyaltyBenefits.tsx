import { ShoppingBag, Calendar, Star } from "lucide-react";

interface Benefit {
  icon: React.ReactNode;
  label: string;
  headline: string;
  body: string;
  detail?: string;
}

const benefits: Benefit[] = [
  {
    icon: <ShoppingBag size={28} strokeWidth={1.5} />,
    label: "01 — EARN",
    headline: "Earn rewards on every purchase",
    body: "Collect 1 point for every £1 you spend — in-store or online. Points convert to money-off vouchers you can spend on anything at Next.",
    detail: "No minimum spend. Points never expire while your account is active.",
  },
  {
    icon: <Calendar size={28} strokeWidth={1.5} />,
    label: "02 — EARLY ACCESS",
    headline: "First to know, first to buy",
    body: "Members get exclusive early access to new collections, seasonal launches, and special sale events — before they open to the public.",
    detail: "Early access invitations sent directly to your email.",
  },
  {
    icon: <Star size={28} strokeWidth={1.5} />,
    label: "03 — RECOGNITION",
    headline: "Recognised in every store",
    body: "Our in-store teams can see your loyalty status at the till — unlocking personalised service, member-only offers, and priority assistance.",
    detail: "Show your loyalty card on the app or at the till.",
  },
];

export function LoyaltyBenefits() {
  return (
    <section style={{ backgroundColor: "#FFFFFF", padding: "80px 0" }}>
      <div className="max-w-[1440px] mx-auto px-6 md:px-16">
        {/* Section header */}
        <div style={{ marginBottom: 56 }}>
          <p
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 500,
              fontSize: 12,
              color: "#007A7A",
              textTransform: "uppercase",
              letterSpacing: "0.16em",
              marginBottom: 12,
            }}
          >
            MEMBER BENEFITS
          </p>
          <h2
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 700,
              fontSize: "clamp(28px, 3.5vw, 44px)",
              color: "#000000",
              lineHeight: 1.15,
              letterSpacing: "-0.01em",
            }}
          >
            Everything you get as a member.
          </h2>
        </div>

        {/* Benefits grid */}
        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-px"
          style={{ backgroundColor: "#E5E5E5" }}
        >
          {benefits.map((b) => (
            <article
              key={b.label}
              style={{
                backgroundColor: "#FFFFFF",
                padding: "40px 36px",
              }}
            >
              {/* Icon */}
              <div
                style={{
                  color: "#007A7A",
                  marginBottom: 24,
                }}
                aria-hidden="true"
              >
                {b.icon}
              </div>

              {/* Label */}
              <p
                style={{
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  fontWeight: 500,
                  fontSize: 11,
                  color: "#999999",
                  textTransform: "uppercase",
                  letterSpacing: "0.16em",
                  marginBottom: 12,
                }}
              >
                {b.label}
              </p>

              {/* Headline */}
              <h3
                style={{
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  fontWeight: 700,
                  fontSize: 22,
                  color: "#000000",
                  lineHeight: 1.25,
                  letterSpacing: "-0.01em",
                  marginBottom: 16,
                }}
              >
                {b.headline}
              </h3>

              {/* Body */}
              <p
                style={{
                  fontFamily: "'Lora', Georgia, serif",
                  fontWeight: 400,
                  fontSize: 16,
                  color: "#555555",
                  lineHeight: 1.65,
                  marginBottom: 16,
                }}
              >
                {b.body}
              </p>

              {/* Detail line */}
              {b.detail && (
                <p
                  style={{
                    fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                    fontWeight: 400,
                    fontSize: 13,
                    color: "#999999",
                    lineHeight: 1.5,
                  }}
                >
                  {b.detail}
                </p>
              )}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
