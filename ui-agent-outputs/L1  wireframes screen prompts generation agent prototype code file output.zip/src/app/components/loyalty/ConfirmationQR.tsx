import { FlowLayout } from "./FlowLayout";

interface ConfirmationQRProps {
  memberName: string;
  requestedPhysicalCard?: boolean;
  onDashboard: () => void;
}

function QRCodeSVG() {
  // Simulated QR code pattern
  const cells = [
    [1,1,1,1,1,1,1,0,1,0,1,0,0,0,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,1,0,0,1,0,1,0,0,1,0,0,0,0,0,1],
    [1,0,1,1,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,1],
    [1,0,1,1,1,0,1,0,0,0,1,1,0,0,1,0,1,1,1,0,1],
    [1,0,1,1,1,0,1,0,1,0,0,1,1,0,1,0,1,1,1,0,1],
    [1,0,0,0,0,0,1,0,0,1,0,0,1,0,1,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1],
    [0,0,0,0,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0],
    [1,0,1,1,0,1,1,1,0,0,1,0,0,1,1,0,1,1,0,1,1],
    [0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,1,0,0,1,0,0],
    [1,1,0,1,0,1,1,0,1,0,1,0,1,0,1,1,0,1,0,1,0],
    [0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,1,0,0,1,0],
    [1,0,1,0,1,0,1,1,0,0,1,0,1,0,0,1,0,1,0,0,1],
    [0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,0,0,1,1,0,0],
    [1,1,1,1,1,1,1,0,0,1,1,0,0,0,1,0,1,0,0,1,0],
    [1,0,0,0,0,0,1,0,1,0,1,0,1,0,0,1,0,0,1,0,1],
    [1,0,1,1,1,0,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1],
    [1,0,1,1,1,0,1,0,1,0,1,0,0,0,1,0,0,0,1,0,0],
    [1,0,1,1,1,0,1,0,0,1,0,0,1,0,0,1,0,1,0,1,0],
    [1,0,0,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1],
    [1,1,1,1,1,1,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0],
  ];

  const size = 21;
  const cellSize = 8;
  const totalSize = size * cellSize;

  return (
    <svg
      width={totalSize}
      height={totalSize}
      viewBox={`0 0 ${totalSize} ${totalSize}`}
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Loyalty QR code"
      role="img"
    >
      <rect width={totalSize} height={totalSize} fill="white" />
      {cells.map((row, y) =>
        row.map((cell, x) =>
          cell ? (
            <rect
              key={`${x}-${y}`}
              x={x * cellSize}
              y={y * cellSize}
              width={cellSize}
              height={cellSize}
              fill="#000000"
            />
          ) : null
        )
      )}
    </svg>
  );
}

export function ConfirmationQR({ memberName, requestedPhysicalCard, onDashboard }: ConfirmationQRProps) {
  const firstName = memberName.split(" ")[0] || memberName;

  return (
    <FlowLayout screen="5.0" title="You're in" hideProgress>
      <div style={{ textAlign: "center" }}>
        {/* Checkmark */}
        <div
          style={{ width: 64, height: 64, backgroundColor: "#DCFCE7", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: 32 }}
          aria-hidden="true"
        >
          ✓
        </div>

        <h1
          style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: "clamp(24px,4vw,34px)", color: "#000000", marginBottom: 8, letterSpacing: "-0.01em" }}
        >
          You're a Next loyalty member
        </h1>

        <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 16, color: "#555555", marginBottom: 28, lineHeight: 1.6 }}>
          Welcome, {firstName}. Your welcome bonus of <strong style={{ color: "#000000" }}>100 points</strong> has been added.
        </p>

        {/* QR card */}
        <div
          style={{ backgroundColor: "#F9F9F9", border: "1px solid #E5E5E5", borderRadius: 8, padding: "28px 24px", display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 14, marginBottom: 20, width: "100%", maxWidth: 280 }}
        >
          <QRCodeSVG />
          <div>
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 16, color: "#000000", marginBottom: 3 }}>
              {memberName} · Member
            </p>
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#007A7A", letterSpacing: "0.04em" }}>
              Scan at any Next till to earn points
            </p>
          </div>
        </div>

        {/* Starting balance */}
        <div
          style={{ backgroundColor: "#EEF2FF", border: "1px solid #C7D7FA", borderRadius: 6, padding: "14px 20px", marginBottom: 28, display: "inline-block", width: "100%", maxWidth: 320 }}
        >
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 12, color: "#4338CA", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
            Your starting balance
          </p>
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 22, color: "#1E3A6E" }}>
            100 pts · worth £1.00
          </p>
        </div>

        {/* Physical card notice */}
        {requestedPhysicalCard && (
          <div
            style={{ backgroundColor: "#F9F9F9", border: "1px solid #E5E5E5", borderRadius: 6, padding: "12px 16px", marginBottom: 24 }}
          >
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, color: "#555555", lineHeight: 1.6 }}>
              Your loyalty card will arrive within 5–7 working days. Use this QR code in the meantime.
            </p>
          </div>
        )}
      </div>

      {/* CTAs */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 8 }}>
        <button
          onClick={onDashboard}
          style={{ width: "100%", backgroundColor: "#000000", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", height: 52, borderRadius: 4, border: "none", cursor: "pointer", transition: "background-color 150ms" }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#333333")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#000000")}
        >
          Go to my loyalty dashboard
        </button>

        <button
          style={{ width: "100%", backgroundColor: "transparent", color: "#000000", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", height: 48, borderRadius: 4, border: "1px solid #000000", cursor: "pointer", transition: "background-color 150ms" }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#F9F9F9")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
          onClick={() => alert("Opens Apple Wallet / Google Wallet native add flow")}
        >
          Save QR code to wallet
        </button>
      </div>

      <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, color: "#999999", textAlign: "center", marginTop: 20 }}>
        <a href="#" target="_blank" rel="noopener noreferrer" style={{ color: "#007A7A", textDecoration: "underline" }}>
          Download the Next app for the full experience
        </a>
      </p>
    </FlowLayout>
  );
}
