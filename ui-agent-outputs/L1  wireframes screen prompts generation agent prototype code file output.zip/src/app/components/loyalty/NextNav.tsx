import { useState } from "react";
import { Search, User, Heart, ShoppingBag, Menu, X } from "lucide-react";

interface NextNavProps {
  onSignInClick: () => void;
  isSignedIn: boolean;
}

export function NextNav({ onSignInClick, isSignedIn }: NextNavProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = ["Women", "Men", "Kids", "Home", "Beauty", "Sale", "Brands"];

  return (
    <header
      style={{ backgroundColor: "#000000", zIndex: 1000 }}
      className="sticky top-0 w-full"
    >
      <div
        className="max-w-[1440px] mx-auto px-6 flex items-center justify-between"
        style={{ height: 64 }}
      >
        {/* Logo */}
        <a
          href="#"
          className="shrink-0"
          aria-label="Next home"
          style={{ letterSpacing: "0.12em" }}
        >
          <span
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 700,
              fontSize: 22,
              color: "#FFFFFF",
              textTransform: "uppercase",
              letterSpacing: "0.18em",
            }}
          >
            NEXT
          </span>
        </a>

        {/* Primary nav — desktop */}
        <nav className="hidden lg:flex items-center gap-8" aria-label="Primary navigation">
          {navLinks.map((link) => (
            <a
              key={link}
              href="#"
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 500,
                fontSize: 13,
                color: link === "Sale" ? "#FF6A3B" : "#FFFFFF",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                textDecoration: "none",
                paddingBottom: 2,
                borderBottom: "2px solid transparent",
                transition: "border-color 150ms",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.borderBottomColor = "#007A7A")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.borderBottomColor = "transparent")
              }
            >
              {link}
            </a>
          ))}
        </nav>

        {/* Utility nav */}
        <div className="flex items-center gap-5">
          <button
            aria-label="Search"
            className="hidden lg:flex"
            style={{ color: "#FFFFFF", background: "none", border: "none", cursor: "pointer" }}
          >
            <Search size={20} />
          </button>

          <button
            aria-label={isSignedIn ? "My account" : "Sign in"}
            onClick={!isSignedIn ? onSignInClick : undefined}
            style={{ color: "#FFFFFF", background: "none", border: "none", cursor: "pointer" }}
          >
            <User size={20} />
          </button>

          <button
            aria-label="Wishlist"
            className="hidden sm:flex"
            style={{ color: "#FFFFFF", background: "none", border: "none", cursor: "pointer" }}
          >
            <Heart size={20} />
          </button>

          <button
            aria-label="Shopping bag, 0 items"
            style={{ color: "#FFFFFF", background: "none", border: "none", cursor: "pointer", position: "relative" }}
          >
            <ShoppingBag size={20} />
          </button>

          {/* Mobile menu toggle */}
          <button
            className="lg:hidden"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            onClick={() => setMobileOpen(!mobileOpen)}
            style={{ color: "#FFFFFF", background: "none", border: "none", cursor: "pointer" }}
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <nav
          className="lg:hidden border-t"
          style={{ borderColor: "#333333", backgroundColor: "#000000" }}
          aria-label="Mobile navigation"
        >
          {navLinks.map((link) => (
            <a
              key={link}
              href="#"
              className="block px-6 py-4"
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 500,
                fontSize: 15,
                color: link === "Sale" ? "#FF6A3B" : "#FFFFFF",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                textDecoration: "none",
                borderBottom: "1px solid #222222",
              }}
            >
              {link}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
