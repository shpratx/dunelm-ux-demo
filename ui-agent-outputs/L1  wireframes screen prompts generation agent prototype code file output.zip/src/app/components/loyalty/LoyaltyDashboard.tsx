import { useState } from "react";
import { X } from "lucide-react";

interface LoyaltyDashboardProps {
  memberName: string;
  points?: number;
  onSignOut?: () => void;
}

const TIER_THRESHOLD = 2500;
const REDEMPTION_THRESHOLD = 500;
const POINTS_PER_POUND = 5;

function TierBadge({ tier }: { tier: string }) {
  const colours: Record<string, string> = { Member: "#555555", Silver: "#4A6FA5", Gold: "#B8860B" };
  return (
    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 22, height: 22, borderRadius: "50%", backgroundColor: colours[tier] ?? "#555555", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 11 }}>
      {tier[0]}
    </span>
  );
}

function QRModal({ name, onClose }: { name: string; onClose: () => void }) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="qr-modal-title"
      style={{ position: "fixed", inset: 0, zIndex: 9000, display: "flex", alignItems: "center", justifyContent: "center", padding: 24, backgroundColor: "rgba(0,0,0,0.6)" }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div style={{ backgroundColor: "#FFFFFF", borderRadius: 12, padding: "36px 32px", width: "100%", maxWidth: 340, textAlign: "center", boxShadow: "0 16px 40px rgba(0,0,0,0.22)", position: "relative" }}>
        <button onClick={onClose} aria-label="Close" style={{ position: "absolute", top: 16, right: 16, background: "none", border: "none", cursor: "pointer", color: "#000000" }}>
          <X size={20} />
        </button>
        <p id="qr-modal-title" style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 16, color: "#000000", marginBottom: 4 }}>
          Show at till
        </p>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#777777", marginBottom: 24 }}>
          Scan this code to earn points on your purchase
        </p>
        {/* QR grid */}
        <div style={{ width: 180, height: 180, margin: "0 auto 16px", background: "repeating-linear-gradient(0deg,#000 0px,#000 8px,#fff 8px,#fff 16px),repeating-linear-gradient(90deg,#000 0px,#000 8px,#fff 8px,#fff 16px)", backgroundBlendMode: "multiply", border: "2px solid #000000", borderRadius: 4 }} aria-hidden="true" />
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 15, color: "#000000", marginBottom: 2 }}>
          {name} · Member
        </p>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#007A7A" }}>
          Next Loyalty
        </p>
      </div>
    </div>
  );
}

const transactions = [
  { id: 1, label: "Welcome bonus", points: 100, date: "Today", positive: true },
];

export function LoyaltyDashboard({ memberName, points = 100, onSignOut }: LoyaltyDashboardProps) {
  const [showQR, setShowQR] = useState(false);
  const tier = "Member";
  const ptsToSilver = TIER_THRESHOLD - points;
  const ptsToReward = REDEMPTION_THRESHOLD - points;
  const tierProgress = Math.min((points / TIER_THRESHOLD) * 100, 100);
  const monetaryValue = (points / POINTS_PER_POUND).toFixed(2);
  const rewardReady = points >= REDEMPTION_THRESHOLD;

  return (
    <div style={{ backgroundColor: "#FFFFFF", minHeight: "100vh" }}>
      {/* Dashboard header */}
      <div style={{ backgroundColor: "#000000", padding: "20px 0 0" }}>
        <div className="max-w-[640px] mx-auto px-6">
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <TierBadge tier={tier} />
              <div>
                <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 14, color: "#FFFFFF" }}>
                  {memberName}
                </p>
                <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 11, color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "0.1em" }}>
                  Next Loyalty · {tier}
                </p>
              </div>
            </div>
            {onSignOut && (
              <button
                onClick={onSignOut}
                style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.45)", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}
              >
                Sign out
              </button>
            )}
          </div>

          {/* Points hero */}
          <div
            style={{ background: "linear-gradient(135deg, #0D1F3C 0%, #1E3A6E 100%)", borderRadius: "10px 10px 0 0", padding: "28px 24px 24px", textAlign: "center" }}
          >
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "rgba(255,255,255,0.55)", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 8 }}>
              YOUR POINTS BALANCE
            </p>
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 800, fontSize: 64, color: "#FFFFFF", lineHeight: 1, letterSpacing: "-0.03em", marginBottom: 6 }}>
              {points.toLocaleString()}
            </p>
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, color: "rgba(255,255,255,0.6)", marginBottom: 20 }}>
              worth £{monetaryValue} · {tier} tier
            </p>

            {/* Tier progress bar */}
            <div style={{ marginBottom: 6 }}>
              <div style={{ height: 5, backgroundColor: "rgba(255,255,255,0.18)", borderRadius: 3, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${tierProgress}%`, backgroundColor: "#4A6FA5", borderRadius: 3, transition: "width 800ms ease" }} />
              </div>
            </div>
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "rgba(255,255,255,0.5)" }}>
              {ptsToSilver.toLocaleString()} pts to Silver · Early Sale Access
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-[640px] mx-auto px-6" style={{ paddingTop: 24, paddingBottom: 80 }}>

        {/* Scan at till — primary CTA */}
        {rewardReady && (
          <div style={{ backgroundColor: "#000000", borderRadius: 6, padding: "16px 20px", marginBottom: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 15, color: "#FFFFFF", marginBottom: 2 }}>
                £5 reward ready to use
              </p>
              <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
                You've reached 500 points
              </p>
            </div>
            <button style={{ backgroundColor: "#007A7A", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.06em", padding: "10px 18px", borderRadius: 4, border: "none", cursor: "pointer", whiteSpace: "nowrap" }}>
              Redeem
            </button>
          </div>
        )}

        <button
          onClick={() => setShowQR(true)}
          style={{ width: "100%", backgroundColor: "#4A6FA5", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 14, textTransform: "uppercase", letterSpacing: "0.08em", height: 52, borderRadius: 4, border: "none", cursor: "pointer", marginBottom: 28, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, transition: "background-color 150ms" }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#3A5F95")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#4A6FA5")}
        >
          ⬛ Scan at till
        </button>

        {/* Divider */}
        <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 20 }} aria-hidden="true" />

        {/* Recent activity */}
        <div style={{ marginBottom: 28 }}>
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 14 }}>
            RECENT ACTIVITY
          </p>
          {transactions.map((txn) => (
            <div key={txn.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid #E5E5E5" }}>
              <div>
                <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 14, color: "#000000" }}>
                  {txn.label}
                </p>
                <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#999999" }}>
                  {txn.date}
                </p>
              </div>
              <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 14, color: txn.positive ? "#1A7A4A" : "#CC2200" }}>
                {txn.positive ? "+" : ""}{txn.points} pts
              </p>
            </div>
          ))}
          <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 14, color: "#AAAAAA", textAlign: "center", padding: "14px 0" }}>
            Your next purchase will appear here
          </p>
        </div>

        {/* Divider */}
        <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 20 }} aria-hidden="true" />

        {/* Rewards section */}
        <div>
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 14 }}>
            REWARDS
          </p>
          {rewardReady ? (
            <div style={{ backgroundColor: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 6, padding: "16px 20px" }}>
              <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 16, color: "#166534", marginBottom: 4 }}>
                £5 reward ready to use
              </p>
              <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 14, color: "#166534", lineHeight: 1.6 }}>
                Apply your voucher at checkout — online or in-store.
              </p>
            </div>
          ) : (
            <div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 15, color: "#333333", lineHeight: 1.6 }}>
                  {ptsToReward} more points to unlock your first <strong>£5 reward</strong>
                </p>
              </div>
              {/* Progress to reward */}
              <div style={{ height: 4, backgroundColor: "#E5E5E5", borderRadius: 2, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${(points / REDEMPTION_THRESHOLD) * 100}%`, backgroundColor: "#007A7A", borderRadius: 2, transition: "width 800ms ease" }} />
              </div>
              <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#999999", marginTop: 6 }}>
                {points} / {REDEMPTION_THRESHOLD} pts
              </p>
            </div>
          )}
        </div>
      </div>

      {/* QR Modal */}
      {showQR && <QRModal name={memberName} onClose={() => setShowQR(false)} />}
    </div>
  );
}
