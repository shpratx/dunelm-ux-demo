import { AlertCircle } from "lucide-react";
import { FlowLayout } from "./FlowLayout";

interface AccountExistsProps {
  email: string;
  onSignIn: () => void;
  onMerge: () => void;
  onUseDifferentEmail: () => void;
}

export function AccountExists({ email, onSignIn, onMerge, onUseDifferentEmail }: AccountExistsProps) {
  const isNextPayEmail = email.toLowerCase().includes("nextpay") || email.toLowerCase().includes("finance");

  return (
    <FlowLayout screen="Er.1" onBack={onUseDifferentEmail} title="Create your account" hideProgress>
      {/* Error banner */}
      <div
        style={{ backgroundColor: "#FEF2F2", border: "1px solid #FCA5A5", borderRadius: 6, padding: "18px 20px", marginBottom: 28 }}
        role="alert"
      >
        <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 8 }}>
          <AlertCircle size={18} color="#CC2200" style={{ flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 15, color: "#CC2200" }}>
            {isNextPayEmail
              ? "This email is linked to your Next Finance account"
              : "An account with this email already exists"}
          </p>
        </div>
        <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 14, color: "#991B1B", lineHeight: 1.65, paddingLeft: 30 }}>
          {isNextPayEmail
            ? `${email} is linked to your Next Finance (NextPay) account. Sign in to connect it to the loyalty programme.`
            : `${email} is linked to an existing Next account. You can sign in to join the loyalty programme, or use a different email address.`}
        </p>
      </div>

      {/* Resolution paths */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 32 }}>
        {/* Primary — sign in */}
        <button
          onClick={onSignIn}
          style={{ width: "100%", backgroundColor: "#000000", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", height: 52, borderRadius: 4, border: "none", cursor: "pointer", transition: "background-color 150ms" }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#333333")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#000000")}
        >
          Sign in to this account
        </button>

        {/* Secondary — merge */}
        <button
          onClick={onMerge}
          style={{ width: "100%", backgroundColor: "transparent", color: "#000000", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", height: 48, borderRadius: 4, border: "1px solid #000000", cursor: "pointer", transition: "background-color 150ms" }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#F9F9F9")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          Merge with a different email
        </button>

        {/* Tertiary — different email */}
        <button
          onClick={onUseDifferentEmail}
          style={{ width: "100%", backgroundColor: "transparent", color: "#555555", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", height: 48, borderRadius: 4, border: "1px solid #E5E5E5", cursor: "pointer", transition: "background-color 150ms" }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#F9F9F9")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          Use a different email address
        </button>
      </div>

      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 20 }} aria-hidden="true" />

      {/* Reassurance */}
      <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 14, color: "#777777", textAlign: "center", lineHeight: 1.65 }}>
        No loyalty history will be lost when accounts are merged.
      </p>
    </FlowLayout>
  );
}
