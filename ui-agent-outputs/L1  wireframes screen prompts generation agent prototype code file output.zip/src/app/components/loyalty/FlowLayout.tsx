import { ArrowLeft } from "lucide-react";

export type FlowScreen = "2.0" | "3.0" | "4.0" | "Er.1" | "5.0" | "6.0";

const STEPS = [
  { id: "2.0", label: "Overview" },
  { id: "3.0", label: "Your data" },
  { id: "4.0", label: "Create account" },
];

interface FlowLayoutProps {
  screen: FlowScreen;
  onBack?: () => void;
  title: string;
  children: React.ReactNode;
  hideProgress?: boolean;
}

export function FlowLayout({ screen, onBack, title, children, hideProgress }: FlowLayoutProps) {
  const stepIndex = STEPS.findIndex((s) => s.id === screen);
  const isEnrolmentStep = stepIndex >= 0;

  return (
    <div style={{ backgroundColor: "#FFFFFF", minHeight: "100vh" }}>
      {/* Flow header */}
      <div
        style={{
          backgroundColor: "#FFFFFF",
          borderBottom: "1px solid #E5E5E5",
          position: "sticky",
          top: 64,
          zIndex: 100,
        }}
      >
        <div
          className="max-w-[640px] mx-auto px-6"
          style={{ paddingTop: 14, paddingBottom: 14, display: "flex", alignItems: "center", gap: 16 }}
        >
          {onBack && (
            <button
              onClick={onBack}
              aria-label="Go back"
              style={{ background: "none", border: "none", cursor: "pointer", color: "#000000", display: "flex", alignItems: "center", gap: 6, fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 13, padding: 0, flexShrink: 0 }}
            >
              <ArrowLeft size={16} />
              <span className="hidden sm:inline">Back</span>
            </button>
          )}
          <h2
            style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 15, color: "#000000", flex: 1, textAlign: onBack ? "center" : "left" }}
          >
            {title}
          </h2>
          {/* Spacer to balance back button */}
          {onBack && <div style={{ width: 52, flexShrink: 0 }} aria-hidden="true" />}
        </div>

        {/* Step progress — only for enrolment steps 2.0–4.0 */}
        {isEnrolmentStep && !hideProgress && (
          <div className="max-w-[640px] mx-auto px-6 pb-3">
            <div style={{ display: "flex", gap: 4 }}>
              {STEPS.map((step, i) => (
                <div
                  key={step.id}
                  style={{
                    flex: 1,
                    height: 3,
                    borderRadius: 2,
                    backgroundColor: i <= stepIndex ? "#000000" : "#E5E5E5",
                    transition: "background-color 300ms",
                  }}
                  aria-hidden="true"
                />
              ))}
            </div>
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 11, color: "#999999", marginTop: 6, letterSpacing: "0.04em" }}>
              Step {stepIndex + 1} of {STEPS.length} — {STEPS[stepIndex].label}
            </p>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="max-w-[640px] mx-auto px-6" style={{ paddingTop: 40, paddingBottom: 80 }}>
        {children}
      </div>
    </div>
  );
}
