import { useState } from "react";
import { Check } from "lucide-react";
import { FlowLayout } from "./FlowLayout";

interface EnrolmentFormProps {
  onBack: () => void;
  onSubmit: (email: string) => void;
  onAccountExists: (email: string) => void;
  prefillEmail?: string;
  prefillLinkAccount?: boolean;
}

function isValidEmail(v: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

function isValidUKMobile(v: string) {
  return /^(\+44|0)7\d{9}$/.test(v.replace(/\s/g, ""));
}

export function EnrolmentForm({ onBack, onSubmit, onAccountExists, prefillEmail, prefillLinkAccount }: EnrolmentFormProps) {
  const [email, setEmail] = useState(prefillEmail ?? "");
  const [emailError, setEmailError] = useState("");
  const [mobile, setMobile] = useState("");
  const [mobileValid, setMobileValid] = useState(false);
  const [linkAccount, setLinkAccount] = useState(prefillLinkAccount ?? false);
  const [physicalCard, setPhysicalCard] = useState(false);
  const [postAddress, setPostAddress] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [magicLinkSent, setMagicLinkSent] = useState(false);

  const emailReadOnly = !!prefillEmail;

  const validateEmail = () => {
    if (!email) { setEmailError("Email address is required."); return false; }
    if (!isValidEmail(email)) { setEmailError("Email address must be a valid format."); return false; }
    setEmailError("");
    return true;
  };

  const handleMobileChange = (v: string) => {
    setMobile(v);
    setMobileValid(isValidUKMobile(v));
  };

  const canSubmit = isValidEmail(email) && !loading;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEmail()) return;
    setLoading(true);

    // Simulate API — "existing@next.co.uk" triggers the duplicate flow
    setTimeout(() => {
      setLoading(false);
      if (email.toLowerCase() === "existing@next.co.uk") {
        onAccountExists(email);
      } else {
        onSubmit(email);
      }
    }, 1100);
  };

  const handleMagicLink = () => {
    if (!validateEmail()) return;
    setMagicLinkSent(true);
  };

  if (magicLinkSent) {
    return (
      <FlowLayout screen="4.0" onBack={onBack} title="Create your account">
        <div style={{ textAlign: "center", paddingTop: 40 }}>
          <div style={{ width: 56, height: 56, backgroundColor: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
            <Check size={24} color="#1A7A4A" strokeWidth={2.5} />
          </div>
          <h2 style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 22, color: "#000000", marginBottom: 12 }}>
            Magic link sent
          </h2>
          <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 16, color: "#555555", lineHeight: 1.65, marginBottom: 32 }}>
            We've sent a sign-in link to <strong style={{ color: "#000000" }}>{email}</strong>. Click it to complete your enrolment — no password needed.
          </p>
          <button
            onClick={() => setMagicLinkSent(false)}
            style={{ background: "none", border: "none", cursor: "pointer", color: "#007A7A", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 13, textDecoration: "underline" }}
          >
            Didn't receive it? Go back
          </button>
        </div>
      </FlowLayout>
    );
  }

  return (
    <FlowLayout screen="4.0" onBack={onBack} title="Create your account">
      <form onSubmit={handleSubmit} noValidate>
        {/* Email */}
        <div style={{ marginBottom: 20 }}>
          <label
            htmlFor="enrol-email"
            style={{ display: "block", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 12, color: "#000000", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}
          >
            Email address <span style={{ color: "#CC2200" }}>*</span>
          </label>
          <input
            id="enrol-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => !emailReadOnly && setEmail(e.target.value)}
            onBlur={validateEmail}
            readOnly={emailReadOnly}
            required
            aria-invalid={!!emailError}
            aria-describedby={emailError ? "enrol-email-error" : undefined}
            placeholder="your@email.com"
            style={{
              width: "100%",
              border: emailError ? "1px solid #CC2200" : "1px solid #E5E5E5",
              borderRadius: 4,
              padding: "12px 16px",
              fontSize: 16,
              fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif",
              outline: "none",
              color: "#000000",
              backgroundColor: emailReadOnly ? "#F2F2F2" : "#FFFFFF",
              boxSizing: "border-box",
              transition: "border-color 150ms",
            }}
            onFocus={(e) => !emailError && !emailReadOnly && (e.currentTarget.style.borderColor = "#007A7A")}
            onBlurCapture={(e) => !emailError && (e.currentTarget.style.borderColor = emailError ? "#CC2200" : "#E5E5E5")}
          />
          {emailError && (
            <p id="enrol-email-error" role="alert" style={{ color: "#CC2200", fontSize: 13, fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", marginTop: 6 }}>
              {emailError}
            </p>
          )}
        </div>

        {/* Mobile */}
        <div style={{ marginBottom: 8 }}>
          <label
            htmlFor="enrol-mobile"
            style={{ display: "block", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 12, color: "#000000", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 6 }}
          >
            Mobile number{" "}
            <span style={{ fontWeight: 400, textTransform: "none", letterSpacing: 0, color: "#777777", fontSize: 12 }}>
              (recommended — used as backup till lookup)
            </span>
          </label>
          <div style={{ position: "relative" }}>
            <input
              id="enrol-mobile"
              type="tel"
              autoComplete="tel"
              value={mobile}
              onChange={(e) => handleMobileChange(e.target.value)}
              placeholder="+44 7700 000000"
              style={{
                width: "100%",
                border: "1px solid #E5E5E5",
                borderRadius: 4,
                padding: "12px 16px",
                paddingRight: mobileValid ? 40 : 16,
                fontSize: 16,
                fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif",
                outline: "none",
                color: "#000000",
                backgroundColor: "#FFFFFF",
                boxSizing: "border-box",
                transition: "border-color 150ms",
              }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#007A7A")}
              onBlur={(e) => (e.currentTarget.style.borderColor = mobileValid ? "#1A7A4A" : "#E5E5E5")}
            />
            {mobileValid && (
              <div style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", color: "#1A7A4A" }}>
                <Check size={18} strokeWidth={2.5} />
              </div>
            )}
          </div>
        </div>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, color: "#4A6FA5", lineHeight: 1.55, marginBottom: 24 }}>
          Adding your mobile means we can find your account at the till even if you forget your email.
        </p>

        {/* Divider */}
        <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 20 }} aria-hidden="true" />

        {/* Optional checkboxes */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
          <Checkbox
            id="link-account"
            checked={linkAccount}
            onChange={setLinkAccount}
            label="Link my existing Next online account"
            disabled={prefillLinkAccount}
          />
          <Checkbox
            id="physical-card"
            checked={physicalCard}
            onChange={setPhysicalCard}
            label="Send me a physical loyalty card by post"
          />
        </div>

        {/* Conditional address field */}
        {physicalCard && (
          <div style={{ marginBottom: 20, backgroundColor: "#F9F9F9", border: "1px solid #E5E5E5", borderRadius: 4, padding: "16px" }}>
            <label
              htmlFor="postal-address"
              style={{ display: "block", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 12, color: "#000000", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}
            >
              Postal address <span style={{ color: "#CC2200" }}>*</span>
            </label>
            <textarea
              id="postal-address"
              value={postAddress}
              onChange={(e) => setPostAddress(e.target.value)}
              placeholder="House number, Street, Town, Postcode"
              rows={3}
              style={{ width: "100%", border: "1px solid #E5E5E5", borderRadius: 4, padding: "10px 14px", fontSize: 15, fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", outline: "none", color: "#000000", backgroundColor: "#FFFFFF", resize: "vertical", boxSizing: "border-box" }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#007A7A")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "#E5E5E5")}
            />
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#777777", marginTop: 6 }}>
              Card arrives within 5–7 working days. You can use a QR code in the meantime.
            </p>
          </div>
        )}

        {/* Divider */}
        <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 20 }} aria-hidden="true" />

        {/* Password */}
        <div style={{ marginBottom: 8 }}>
          <label
            htmlFor="enrol-password"
            style={{ display: "block", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 12, color: "#000000", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}
          >
            Create a password
          </label>
          <input
            id="enrol-password"
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Min. 8 characters"
            style={{ width: "100%", border: "1px solid #E5E5E5", borderRadius: 4, padding: "12px 16px", fontSize: 16, fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", outline: "none", color: "#000000", backgroundColor: "#FFFFFF", boxSizing: "border-box", transition: "border-color 150ms" }}
            onFocus={(e) => (e.currentTarget.style.borderColor = "#007A7A")}
            onBlur={(e) => (e.currentTarget.style.borderColor = "#E5E5E5")}
          />
        </div>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, color: "#555555", marginBottom: 32, lineHeight: 1.55 }}>
          Or{" "}
          <button
            type="button"
            onClick={handleMagicLink}
            style={{ background: "none", border: "none", cursor: "pointer", color: "#007A7A", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, textDecoration: "underline", padding: 0 }}
          >
            continue with a magic link
          </button>{" "}
          — we'll email you a sign-in link instead.
        </p>

        {/* Primary CTA */}
        <button
          type="submit"
          disabled={!canSubmit}
          style={{
            width: "100%",
            backgroundColor: canSubmit ? "#000000" : "#CCCCCC",
            color: "#FFFFFF",
            fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif",
            fontWeight: 600,
            fontSize: 13,
            textTransform: "uppercase",
            letterSpacing: "0.06em",
            height: 52,
            borderRadius: 4,
            border: "none",
            cursor: canSubmit ? "pointer" : "not-allowed",
            opacity: canSubmit ? 1 : 0.55,
            transition: "background-color 150ms",
          }}
        >
          {loading ? "Creating your account…" : "Create my loyalty account"}
        </button>

        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#777777", textAlign: "center", marginTop: 16, lineHeight: 1.55 }}>
          To test the duplicate email state, use{" "}
          <code style={{ fontSize: 11, backgroundColor: "#F2F2F2", padding: "1px 5px", borderRadius: 2 }}>existing@next.co.uk</code>
        </p>
      </form>
    </FlowLayout>
  );
}

function Checkbox({ id, checked, onChange, label, disabled }: { id: string; checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label htmlFor={id} style={{ display: "flex", alignItems: "flex-start", gap: 12, cursor: disabled ? "default" : "pointer" }}>
      <div
        id={id}
        role="checkbox"
        aria-checked={checked}
        tabIndex={0}
        onClick={() => !disabled && onChange(!checked)}
        onKeyDown={(e) => e.key === " " && !disabled && onChange(!checked)}
        style={{
          width: 20,
          height: 20,
          border: checked ? "none" : "2px solid #CCCCCC",
          borderRadius: 3,
          backgroundColor: checked ? "#000000" : "#FFFFFF",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          marginTop: 2,
          cursor: disabled ? "default" : "pointer",
          transition: "background-color 150ms",
          opacity: disabled ? 0.5 : 1,
        }}
      >
        {checked && <Check size={12} color="#FFFFFF" strokeWidth={3} />}
      </div>
      <span style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 14, color: "#333333", lineHeight: 1.55 }}>
        {label}
      </span>
    </label>
  );
}
