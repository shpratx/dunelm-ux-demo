import { FlowLayout } from "./FlowLayout";

interface ProgrammeOverviewProps {
  onBack: () => void;
  onContinue: () => void;
  checkoutBasketPoints?: number;
}

const tiers = [
  {
    code: "M",
    name: "Member",
    colour: "#555555",
    perks: "Earn points on every purchase",
  },
  {
    code: "S",
    name: "Silver",
    colour: "#4A6FA5",
    perks: "Early sale access + bonus earn events",
  },
  {
    code: "G",
    name: "Gold",
    colour: "#B8860B",
    perks: "Extended sale access + exclusive collections",
  },
];

export function ProgrammeOverview({ onBack, onContinue, checkoutBasketPoints }: ProgrammeOverviewProps) {
  return (
    <FlowLayout screen="2.0" onBack={onBack} title="How it works">
      {/* Checkout basket preview — Variation 2 conditional */}
      {checkoutBasketPoints != null && (
        <div
          style={{ backgroundColor: "#EEF2FF", border: "1px solid #C7D7FA", borderRadius: 6, padding: "16px 20px", marginBottom: 28 }}
        >
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 12, color: "#4338CA", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
            Your basket
          </p>
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 22, color: "#1E3A6E", marginBottom: 2 }}>
            {checkoutBasketPoints} points
          </p>
          <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 14, color: "#4338CA" }}>
            This purchase will earn you {checkoutBasketPoints} points — worth £{(checkoutBasketPoints / 500 * 5).toFixed(2)} in rewards
          </p>
        </div>
      )}

      {/* Earn mechanic — the memorisable sentence */}
      <div style={{ marginBottom: 32 }}>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 12 }}>
          EARN
        </p>
        <div
          style={{ backgroundColor: "#EEF2FF", border: "1px solid #C7D7FA", borderRadius: 6, padding: "20px 24px" }}
        >
          <p
            style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 18, color: "#1E3A6E", lineHeight: 1.4, marginBottom: 8 }}
          >
            Spend £1 · Earn 5 points · 500 points = £5 reward
          </p>
          <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 15, color: "#3730A3", lineHeight: 1.6 }}>
            Every purchase counts. Online, in-store, Click &amp; Collect.
          </p>
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 32 }} aria-hidden="true" />

      {/* Tier structure */}
      <div style={{ marginBottom: 32 }}>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 16 }}>
          TIERS
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {tiers.map((tier) => (
            <div
              key={tier.code}
              style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "14px 16px", border: "1px solid #E5E5E5", borderRadius: 4 }}
            >
              <div
                style={{ width: 32, height: 32, backgroundColor: tier.colour, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 14, flexShrink: 0 }}
              >
                {tier.code}
              </div>
              <div>
                <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 15, color: "#000000", marginBottom: 2 }}>
                  {tier.name}
                </p>
                <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 14, color: "#555555", lineHeight: 1.5 }}>
                  {tier.perks}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 24 }} aria-hidden="true" />

      {/* Physical card */}
      <div style={{ marginBottom: 40 }}>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 10 }}>
          PHYSICAL CARD AVAILABLE
        </p>
        <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 15, color: "#333333", lineHeight: 1.65 }}>
          Don't have a smartphone? Request a loyalty card — it works at every Next till. You can add this option during sign-up.
        </p>
      </div>

      {/* T&Cs tertiary link */}
      <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#999999", marginBottom: 24, lineHeight: 1.6 }}>
        Tier status is determined after enrolment based on your purchase history. Points values shown are illustrative.{" "}
        <a href="#" target="_blank" rel="noopener noreferrer" style={{ color: "#007A7A", textDecoration: "underline" }}>
          Full programme terms
        </a>
      </p>

      {/* Primary CTA */}
      <button
        onClick={onContinue}
        style={{ width: "100%", backgroundColor: "#000000", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", padding: "0 24px", height: 52, borderRadius: 4, border: "none", cursor: "pointer", transition: "background-color 150ms" }}
        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#333333")}
        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#000000")}
      >
        Continue to sign up
      </button>
    </FlowLayout>
  );
}
