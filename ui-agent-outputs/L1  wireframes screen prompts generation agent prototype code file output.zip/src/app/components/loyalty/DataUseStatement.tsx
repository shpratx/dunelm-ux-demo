import { useState } from "react";
import { Check, X } from "lucide-react";
import { FlowLayout } from "./FlowLayout";

interface DataUseStatementProps {
  onBack: () => void;
  onContinue: (marketingOptIn: boolean) => void;
  isNextPayUser?: boolean;
}

const tracked = [
  "Purchases — to calculate and credit your points",
  "Loyalty account activity — to maintain your balance and tier",
];

const notDone = [
  "Use your loyalty data to restrict your account or penalise returns",
  "Share your data with third parties for advertising",
];

export function DataUseStatement({ onBack, onContinue, isNextPayUser }: DataUseStatementProps) {
  const [acknowledged, setAcknowledged] = useState(false);
  const [marketingOptIn, setMarketingOptIn] = useState(false);

  return (
    <FlowLayout screen="3.0" onBack={onBack} title="Your data & privacy">
      {/* NextPay note — conditional */}
      {isNextPayUser && (
        <div
          style={{ backgroundColor: "#EEF2FF", border: "1px solid #C7D7FA", borderRadius: 6, padding: "14px 18px", marginBottom: 24 }}
        >
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 13, color: "#3730A3", lineHeight: 1.6 }}>
            Your NextPay account data is managed separately under your credit agreement — this loyalty programme uses a separate data layer.
          </p>
        </div>
      )}

      {/* Trust box */}
      <div
        style={{ backgroundColor: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 6, padding: "20px 22px", marginBottom: 28 }}
      >
        <h2
          style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: 17, color: "#166534", marginBottom: 10, lineHeight: 1.3 }}
        >
          How we use your loyalty data
        </h2>
        <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 15, color: "#166534", lineHeight: 1.7 }}>
          We track your purchases to give you rewards and recognise you as a loyal customer. We do not use your loyalty data to restrict your account or penalise returns.
        </p>
      </div>

      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 24 }} aria-hidden="true" />

      {/* What we track */}
      <div style={{ marginBottom: 24 }}>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 14 }}>
          WHAT WE TRACK
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {tracked.map((item) => (
            <div key={item} style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
              <div style={{ width: 22, height: 22, backgroundColor: "#1A7A4A", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}>
                <Check size={12} color="#FFFFFF" strokeWidth={3} />
              </div>
              <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 15, color: "#333333", lineHeight: 1.6 }}>
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 24 }} aria-hidden="true" />

      {/* What we don't do */}
      <div style={{ marginBottom: 32 }}>
        <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#777777", textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 14 }}>
          WHAT WE DON'T DO
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {notDone.map((item) => (
            <div key={item} style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
              <div style={{ width: 22, height: 22, backgroundColor: "#CC2200", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}>
                <X size={12} color="#FFFFFF" strokeWidth={3} />
              </div>
              <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 15, color: "#333333", lineHeight: 1.6 }}>
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "#E5E5E5", marginBottom: 24 }} aria-hidden="true" />

      {/* Checkboxes */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 32 }}>
        {/* Mandatory */}
        <label
          style={{ display: "flex", alignItems: "flex-start", gap: 12, cursor: "pointer" }}
        >
          <div
            onClick={() => setAcknowledged(!acknowledged)}
            role="checkbox"
            aria-checked={acknowledged}
            tabIndex={0}
            onKeyDown={(e) => e.key === " " && setAcknowledged(!acknowledged)}
            style={{ width: 20, height: 20, border: acknowledged ? "none" : "2px solid #CCCCCC", borderRadius: 3, backgroundColor: acknowledged ? "#000000" : "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2, cursor: "pointer", transition: "background-color 150ms, border 150ms" }}
          >
            {acknowledged && <Check size={12} color="#FFFFFF" strokeWidth={3} />}
          </div>
          <span style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 14, color: "#000000", lineHeight: 1.55 }}>
            I understand how Next will use my loyalty data <span style={{ color: "#CC2200" }}>*</span>
          </span>
        </label>

        {/* Optional marketing */}
        <label
          style={{ display: "flex", alignItems: "flex-start", gap: 12, cursor: "pointer" }}
        >
          <div
            onClick={() => setMarketingOptIn(!marketingOptIn)}
            role="checkbox"
            aria-checked={marketingOptIn}
            tabIndex={0}
            onKeyDown={(e) => e.key === " " && setMarketingOptIn(!marketingOptIn)}
            style={{ width: 20, height: 20, border: marketingOptIn ? "none" : "2px solid #CCCCCC", borderRadius: 3, backgroundColor: marketingOptIn ? "#000000" : "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2, cursor: "pointer", transition: "background-color 150ms, border 150ms" }}
          >
            {marketingOptIn && <Check size={12} color="#FFFFFF" strokeWidth={3} />}
          </div>
          <span style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 14, color: "#333333", lineHeight: 1.55 }}>
            I'd like to receive personalised sale and offer emails{" "}
            <span style={{ color: "#777777", fontSize: 13 }}>(optional)</span>
          </span>
        </label>
      </div>

      {/* Privacy policy link — tertiary */}
      <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 12, color: "#999999", marginBottom: 24 }}>
        <a href="#" target="_blank" rel="noopener noreferrer" style={{ color: "#007A7A", textDecoration: "underline" }}>
          Read the full privacy policy
        </a>
      </p>

      {/* Primary CTA — disabled until acknowledged */}
      <button
        onClick={() => acknowledged && onContinue(marketingOptIn)}
        disabled={!acknowledged}
        aria-disabled={!acknowledged}
        style={{
          width: "100%",
          backgroundColor: acknowledged ? "#000000" : "#CCCCCC",
          color: "#FFFFFF",
          fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif",
          fontWeight: 600,
          fontSize: 13,
          textTransform: "uppercase",
          letterSpacing: "0.06em",
          padding: "0 24px",
          height: 52,
          borderRadius: 4,
          border: "none",
          cursor: acknowledged ? "pointer" : "not-allowed",
          transition: "background-color 200ms",
          opacity: acknowledged ? 1 : 0.55,
        }}
      >
        I Understand — Continue
      </button>
    </FlowLayout>
  );
}
