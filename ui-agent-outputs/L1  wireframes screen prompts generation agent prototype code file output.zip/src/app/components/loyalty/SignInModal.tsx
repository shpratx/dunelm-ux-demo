import { useState } from "react";
import { X } from "lucide-react";

interface SignInModalProps {
  onClose: () => void;
  onSignedIn: (email: string) => void;
}

export function SignInModal({ onClose, onSignedIn }: SignInModalProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [loading, setLoading] = useState(false);

  const validate = () => {
    if (!email || !email.includes("@")) {
      setEmailError("Email address must include an @ symbol.");
      return false;
    }
    setEmailError("");
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSignedIn(email);
    }, 900);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="signin-modal-heading"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
        backgroundColor: "rgba(0,0,0,0.5)",
      }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        style={{
          backgroundColor: "#FFFFFF",
          borderRadius: 8,
          width: "100%",
          maxWidth: 480,
          padding: "40px 40px 40px",
          position: "relative",
          boxShadow: "0 16px 40px rgba(0,0,0,0.18)",
        }}
      >
        {/* Close */}
        <button
          onClick={onClose}
          aria-label="Close sign in"
          style={{
            position: "absolute",
            top: 20,
            right: 20,
            background: "none",
            border: "none",
            cursor: "pointer",
            color: "#000000",
            padding: 4,
          }}
        >
          <X size={20} />
        </button>

        {/* Heading */}
        <h2
          id="signin-modal-heading"
          style={{
            fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
            fontWeight: 700,
            fontSize: 28,
            color: "#000000",
            marginBottom: 8,
            letterSpacing: "-0.01em",
          }}
        >
          Sign in
        </h2>
        <p
          style={{
            fontFamily: "'Lora', Georgia, serif",
            fontSize: 15,
            color: "#555555",
            marginBottom: 32,
            lineHeight: 1.6,
          }}
        >
          Use your existing Next or NextPay account details.
        </p>

        <form onSubmit={handleSubmit} noValidate>
          {/* Email */}
          <div style={{ marginBottom: 20 }}>
            <label
              htmlFor="signin-email"
              style={{
                display: "block",
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 500,
                fontSize: 13,
                color: "#000000",
                marginBottom: 8,
                textTransform: "uppercase",
                letterSpacing: "0.06em",
              }}
            >
              Email address *
            </label>
            <input
              id="signin-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onBlur={validate}
              required
              aria-invalid={!!emailError}
              aria-describedby={emailError ? "email-error" : undefined}
              style={{
                width: "100%",
                border: emailError ? "1px solid #CC2200" : "1px solid #E5E5E5",
                borderRadius: 4,
                padding: "12px 16px",
                fontSize: 16,
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                outline: "none",
                color: "#000000",
                backgroundColor: "#FFFFFF",
                transition: "border-color 150ms",
                boxSizing: "border-box",
              }}
              onFocus={(e) =>
                !emailError && (e.currentTarget.style.borderColor = "#007A7A")
              }
              onBlurCapture={(e) =>
                !emailError && (e.currentTarget.style.borderColor = "#E5E5E5")
              }
            />
            {emailError && (
              <p
                id="email-error"
                role="alert"
                style={{
                  color: "#CC2200",
                  fontSize: 13,
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  marginTop: 6,
                }}
              >
                {emailError}
              </p>
            )}
          </div>

          {/* Password */}
          <div style={{ marginBottom: 32 }}>
            <label
              htmlFor="signin-password"
              style={{
                display: "block",
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 500,
                fontSize: 13,
                color: "#000000",
                marginBottom: 8,
                textTransform: "uppercase",
                letterSpacing: "0.06em",
              }}
            >
              Password *
            </label>
            <input
              id="signin-password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                border: "1px solid #E5E5E5",
                borderRadius: 4,
                padding: "12px 16px",
                fontSize: 16,
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                outline: "none",
                color: "#000000",
                backgroundColor: "#FFFFFF",
                transition: "border-color 150ms",
                boxSizing: "border-box",
              }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#007A7A")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "#E5E5E5")}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: "100%",
              backgroundColor: loading ? "#555555" : "#000000",
              color: "#FFFFFF",
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 600,
              fontSize: 13,
              textTransform: "uppercase",
              letterSpacing: "0.06em",
              padding: "14px 24px",
              borderRadius: 4,
              border: "none",
              cursor: loading ? "not-allowed" : "pointer",
              height: 52,
              transition: "background-color 150ms",
            }}
          >
            {loading ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <p
          style={{
            marginTop: 24,
            fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
            fontSize: 13,
            color: "#777777",
            textAlign: "center",
          }}
        >
          Forgotten your password?{" "}
          <a href="#" style={{ color: "#007A7A", textDecoration: "underline" }}>
            Reset it here
          </a>
        </p>
      </div>
    </div>
  );
}
