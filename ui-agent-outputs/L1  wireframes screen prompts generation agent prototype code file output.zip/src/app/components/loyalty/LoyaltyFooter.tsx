export function LoyaltyFooter() {
  const links = [
    { group: "About", items: ["About Next", "Sustainability", "Careers", "Press"] },
    {
      group: "Help",
      items: ["Delivery Information", "Returns", "Size Guide", "Contact Us"],
    },
    {
      group: "Loyalty",
      items: [
        "Programme Rules",
        "FAQs",
        "Privacy & Data Use",
        "Terms & Conditions",
      ],
    },
  ];

  return (
    <footer style={{ backgroundColor: "#000000" }}>
      {/* Divider */}
      <div style={{ height: 1, backgroundColor: "rgba(255,255,255,0.08)" }} aria-hidden="true" />

      <div
        className="max-w-[1440px] mx-auto px-6 md:px-16"
        style={{ paddingTop: 56, paddingBottom: 40 }}
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {/* Logo + tagline */}
          <div>
            <p
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 700,
                fontSize: 20,
                color: "#FFFFFF",
                letterSpacing: "0.18em",
                textTransform: "uppercase",
                marginBottom: 12,
              }}
            >
              NEXT
            </p>
            <p
              style={{
                fontFamily: "'Lora', Georgia, serif",
                fontSize: 14,
                color: "rgba(255,255,255,0.45)",
                lineHeight: 1.6,
              }}
            >
              Fashion, footwear, home
              <br />& accessories.
            </p>
          </div>

          {links.map((col) => (
            <div key={col.group}>
              <p
                style={{
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  fontWeight: 600,
                  fontSize: 11,
                  color: "rgba(255,255,255,0.4)",
                  textTransform: "uppercase",
                  letterSpacing: "0.14em",
                  marginBottom: 16,
                }}
              >
                {col.group}
              </p>
              <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
                {col.items.map((item) => (
                  <li key={item} style={{ marginBottom: 10 }}>
                    <a
                      href="#"
                      style={{
                        fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                        fontSize: 14,
                        color: "rgba(255,255,255,0.6)",
                        textDecoration: "none",
                        transition: "color 150ms",
                      }}
                      onMouseEnter={(e) =>
                        (e.currentTarget.style.color = "#FFFFFF")
                      }
                      onMouseLeave={(e) =>
                        (e.currentTarget.style.color = "rgba(255,255,255,0.6)")
                      }
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div
          style={{
            borderTop: "1px solid rgba(255,255,255,0.08)",
            paddingTop: 24,
            display: "flex",
            flexWrap: "wrap",
            gap: 16,
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <p
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontSize: 12,
              color: "rgba(255,255,255,0.35)",
            }}
          >
            © 2026 Next Retail Ltd. All rights reserved.
          </p>
          <p
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontSize: 12,
              color: "rgba(255,255,255,0.35)",
            }}
          >
            Loyalty programme is free to join and separate from NextPay credit services.
          </p>
        </div>
      </div>
    </footer>
  );
}
