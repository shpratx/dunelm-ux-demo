import { ChevronDown, Star, Zap, CheckCircle } from "lucide-react";

export type UserState = "anonymous" | "no-loyalty" | "member";

interface LoyaltyHeroProps {
  userState: UserState;
  userEmail?: string;
  onJoin: () => void;
  onSignIn: () => void;
}

const benefits = [
  {
    icon: <Star size={14} fill="currentColor" />,
    title: "Earn points",
    body: "on every purchase — online, in-store, Click & Collect",
  },
  {
    icon: <Zap size={14} fill="currentColor" />,
    title: "Early sale access",
    body: "— earn your way into the Next Sale before anyone else",
  },
  {
    icon: <CheckCircle size={14} />,
    title: "In-store recognition",
    body: "— your loyalty shows at the till",
  },
];

export function LoyaltyHero({ userState, userEmail, onJoin, onSignIn }: LoyaltyHeroProps) {
  const scrollToEarn = () => {
    document.getElementById("how-it-works")?.scrollIntoView({ behavior: "smooth" });
  };

  if (userState === "member") {
    return (
      <section
        style={{ backgroundColor: "#000000", minHeight: "50vh" }}
        className="flex items-center justify-center px-6 py-20"
      >
        <div className="text-center max-w-lg">
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 12, color: "#007A7A", textTransform: "uppercase", letterSpacing: "0.16em", marginBottom: 24 }}>
            NEXT LOYALTY
          </p>
          <h1 style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: "clamp(32px,5vw,52px)", color: "#FFFFFF", lineHeight: 1.15, marginBottom: 20 }}>
            Welcome back.
          </h1>
          <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 18, color: "rgba(255,255,255,0.75)", marginBottom: 40, lineHeight: 1.6 }}>
            You're already a loyalty member. Taking you to your dashboard…
          </p>
          <button
            onClick={onJoin}
            style={{ display: "inline-block", backgroundColor: "#FFFFFF", color: "#000000", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", padding: "14px 32px", borderRadius: 4, border: "none", cursor: "pointer" }}
          >
            Go to My Loyalty Dashboard
          </button>
        </div>
      </section>
    );
  }

  return (
    <section style={{ backgroundColor: "#000000" }} className="relative overflow-hidden">
      {/* Subtle background teal radial */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 70% 55% at 65% 45%, rgba(0,122,122,0.09) 0%, transparent 65%)" }}
        aria-hidden="true"
      />

      <div className="max-w-[1440px] mx-auto px-6 md:px-16 py-16 md:py-24 relative">
        <div className="max-w-xl">
          {/* Eyebrow */}
          <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 500, fontSize: 11, color: "#007A7A", textTransform: "uppercase", letterSpacing: "0.18em", marginBottom: 24 }}>
            NEXT LOYALTY
          </p>

          {/* H1 */}
          <h1 style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 700, fontSize: "clamp(38px,6vw,68px)", color: "#FFFFFF", lineHeight: 1.08, letterSpacing: "-0.02em", marginBottom: 0 }}>
            {userState === "no-loyalty" ? "Complete your enrolment." : "Earn rewards every time you shop."}
          </h1>

          {/* KEY ANXIETY RESOLVER — most prominent secondary element */}
          <div style={{ marginTop: 24, marginBottom: 24, display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 3, height: 32, backgroundColor: "#007A7A", borderRadius: 2, flexShrink: 0 }} aria-hidden="true" />
            <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: "clamp(18px,2.4vw,24px)", color: "#FFFFFF", letterSpacing: "-0.01em", lineHeight: 1.25 }}>
              No credit account needed. Open to every Next customer.
            </p>
          </div>

          {/* Pre-populated email for no-loyalty state */}
          {userState === "no-loyalty" && userEmail && (
            <div style={{ marginBottom: 24 }}>
              <p style={{ fontFamily: "'Lora',Georgia,serif", fontSize: 16, color: "rgba(255,255,255,0.7)", lineHeight: 1.6, marginBottom: 16 }}>
                You're signed in as <strong style={{ color: "#FFFFFF" }}>{userEmail}</strong>. Join the loyalty programme to start earning rewards.
              </p>
            </div>
          )}

          {userState === "anonymous" && (
            <p style={{ fontFamily: "'Lora',Georgia,serif", fontWeight: 400, fontSize: 17, color: "rgba(255,255,255,0.68)", lineHeight: 1.65, marginBottom: 28, maxWidth: 480 }}>
              Join free today and earn points on every purchase — in-store and online.
            </p>
          )}

          {/* Benefits list */}
          <div style={{ marginBottom: 32, display: "flex", flexDirection: "column", gap: 10 }}>
            {benefits.map((b) => (
              <div key={b.title} style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                <div style={{ width: 24, height: 24, backgroundColor: "#007A7A", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", color: "#FFFFFF", flexShrink: 0, marginTop: 1 }}>
                  {b.icon}
                </div>
                <p style={{ fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontSize: 15, color: "rgba(255,255,255,0.85)", lineHeight: 1.5 }}>
                  <strong style={{ color: "#FFFFFF", fontWeight: 600 }}>{b.title}</strong>{" "}{b.body}
                </p>
              </div>
            ))}
          </div>

          {/* Divider */}
          <div style={{ height: 1, backgroundColor: "rgba(255,255,255,0.1)", marginBottom: 28 }} aria-hidden="true" />

          {/* CTA cluster */}
          <div className="flex flex-wrap items-center gap-3" style={{ marginBottom: 24 }}>
            <button
              onClick={onJoin}
              style={{ backgroundColor: "#FFFFFF", color: "#000000", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", padding: "0 28px", borderRadius: 4, border: "none", cursor: "pointer", height: 50, transition: "background-color 150ms", whiteSpace: "nowrap" }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#F2F2F2")}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#FFFFFF")}
            >
              {userState === "no-loyalty" ? "Complete Enrolment" : "Join the Loyalty Programme"}
            </button>

            {userState === "anonymous" && (
              <button
                onClick={onSignIn}
                style={{ backgroundColor: "transparent", color: "#FFFFFF", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 600, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em", padding: "0 28px", borderRadius: 4, border: "1px solid rgba(255,255,255,0.35)", cursor: "pointer", height: 50, transition: "border-color 150ms", whiteSpace: "nowrap" }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.75)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.35)")}
              >
                Sign in to existing account
              </button>
            )}
          </div>

          {/* Learn more scroll link */}
          {userState === "anonymous" && (
            <button
              onClick={scrollToEarn}
              style={{ background: "none", border: "none", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 5, color: "rgba(255,255,255,0.42)", fontFamily: "'Barlow','Helvetica Neue',Arial,sans-serif", fontWeight: 400, fontSize: 12, letterSpacing: "0.06em", textTransform: "uppercase", padding: 0, transition: "color 150ms" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.85)")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.42)")}
              aria-label="Scroll to how it works section"
            >
              Learn how it works <ChevronDown size={14} />
            </button>
          )}
        </div>
      </div>

      <div style={{ height: 1, backgroundColor: "rgba(255,255,255,0.07)" }} aria-hidden="true" />
    </section>
  );
}
