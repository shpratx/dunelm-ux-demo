import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

interface EarnStep {
  step: string;
  title: string;
  body: string;
}

const earnSteps: EarnStep[] = [
  {
    step: "1",
    title: "Shop in-store or online",
    body: "Every £1 you spend at Next — in any of our stores or on next.co.uk — earns 1 loyalty point. No minimum basket. No exclusions.",
  },
  {
    step: "2",
    title: "Points build into vouchers",
    body: "Collect 500 points and we'll automatically issue a £5 reward voucher to your account. Vouchers stack — you can save them up for a larger treat.",
  },
  {
    step: "3",
    title: "Redeem on anything, any time",
    body: "Use your vouchers in-store or online against any purchase. No restrictions on categories, no minimum spend required for redemption.",
  },
];

const earningRates = [
  { channel: "Online purchase", rate: "1 pt / £1", bonus: "" },
  { channel: "In-store purchase", rate: "1 pt / £1", bonus: "" },
  { channel: "Birthday month", rate: "2 pts / £1", bonus: "Bonus month" },
  { channel: "First purchase", rate: "+100 pts", bonus: "Welcome bonus" },
];

const faqs = [
  {
    q: "Do I need a Next credit account?",
    a: "No. The Next Loyalty Programme is completely separate from NextPay and our credit accounts. All you need is a free Next account, which you can create with any email address.",
  },
  {
    q: "How do I earn points in-store?",
    a: "Just give your loyalty number at the till — you'll find it in the Next app or on your loyalty card. Our team will apply your points at checkout.",
  },
  {
    q: "When do my points expire?",
    a: "Points remain active as long as you make at least one purchase every 24 months. Vouchers issued from points are valid for 6 months from the date of issue.",
  },
  {
    q: "Can I link my existing Next account?",
    a: "Yes — if you already have a Next account or NextPay account, sign in with those credentials to link your loyalty membership automatically.",
  },
  {
    q: "How are rewards issued?",
    a: "Once you reach 500 points, a £5 voucher is automatically added to your account within 24 hours. You'll receive an email confirmation.",
  },
];

export function EarnDetail() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <section
      id="how-it-works"
      style={{ backgroundColor: "#F9F9F9", scrollMarginTop: 80 }}
    >
      {/* How it works */}
      <div
        className="max-w-[1440px] mx-auto px-6 md:px-16"
        style={{ paddingTop: 80, paddingBottom: 64 }}
      >
        <div style={{ marginBottom: 56 }}>
          <p
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 500,
              fontSize: 12,
              color: "#007A7A",
              textTransform: "uppercase",
              letterSpacing: "0.16em",
              marginBottom: 12,
            }}
          >
            HOW IT WORKS
          </p>
          <h2
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 700,
              fontSize: "clamp(26px, 3vw, 40px)",
              color: "#000000",
              lineHeight: 1.15,
              letterSpacing: "-0.01em",
            }}
          >
            Earn, collect, and redeem — simply.
          </h2>
        </div>

        {/* Step-by-step */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {earnSteps.map((s) => (
            <div key={s.step}>
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  backgroundColor: "#000000",
                  color: "#FFFFFF",
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  fontWeight: 700,
                  fontSize: 16,
                  marginBottom: 20,
                }}
              >
                {s.step}
              </div>
              <h3
                style={{
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  fontWeight: 700,
                  fontSize: 20,
                  color: "#000000",
                  marginBottom: 12,
                  lineHeight: 1.3,
                }}
              >
                {s.title}
              </h3>
              <p
                style={{
                  fontFamily: "'Lora', Georgia, serif",
                  fontSize: 16,
                  color: "#555555",
                  lineHeight: 1.65,
                }}
              >
                {s.body}
              </p>
            </div>
          ))}
        </div>

        {/* Earning rate table */}
        <div
          style={{
            backgroundColor: "#FFFFFF",
            border: "1px solid #E5E5E5",
            borderRadius: 2,
            overflow: "hidden",
            marginBottom: 24,
          }}
        >
          <div
            style={{
              padding: "16px 24px",
              borderBottom: "1px solid #E5E5E5",
              backgroundColor: "#F2F2F2",
            }}
          >
            <p
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 600,
                fontSize: 12,
                color: "#555555",
                textTransform: "uppercase",
                letterSpacing: "0.12em",
              }}
            >
              EARNING RATES
            </p>
          </div>
          {earningRates.map((row, i) => (
            <div
              key={row.channel}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "16px 24px",
                borderBottom: i < earningRates.length - 1 ? "1px solid #E5E5E5" : "none",
              }}
            >
              <div>
                <p
                  style={{
                    fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 15,
                    color: "#000000",
                  }}
                >
                  {row.channel}
                </p>
                {row.bonus && (
                  <p
                    style={{
                      fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                      fontSize: 12,
                      color: "#007A7A",
                      marginTop: 2,
                    }}
                  >
                    {row.bonus}
                  </p>
                )}
              </div>
              <p
                style={{
                  fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                  fontWeight: 700,
                  fontSize: 15,
                  color: "#000000",
                  whiteSpace: "nowrap",
                }}
              >
                {row.rate}
              </p>
            </div>
          ))}
        </div>

        {/* Threshold callout */}
        <div
          style={{
            backgroundColor: "#000000",
            borderRadius: 2,
            padding: "24px 32px",
            display: "flex",
            flexWrap: "wrap",
            alignItems: "center",
            gap: 16,
            justifyContent: "space-between",
            marginBottom: 80,
          }}
        >
          <div>
            <p
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 700,
                fontSize: 18,
                color: "#FFFFFF",
                marginBottom: 4,
              }}
            >
              500 points = £5 reward
            </p>
            <p
              style={{
                fontFamily: "'Lora', Georgia, serif",
                fontSize: 15,
                color: "rgba(255,255,255,0.65)",
              }}
            >
              Vouchers issued automatically — no claiming required.
            </p>
          </div>
          <div
            style={{
              backgroundColor: "#007A7A",
              borderRadius: 4,
              padding: "8px 20px",
            }}
          >
            <p
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontWeight: 700,
                fontSize: 22,
                color: "#FFFFFF",
                letterSpacing: "-0.01em",
              }}
            >
              1%
            </p>
            <p
              style={{
                fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                fontSize: 11,
                color: "rgba(255,255,255,0.75)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
              }}
            >
              back on all spend
            </p>
          </div>
        </div>

        {/* FAQs */}
        <div>
          <h2
            style={{
              fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
              fontWeight: 700,
              fontSize: "clamp(22px, 2.5vw, 32px)",
              color: "#000000",
              marginBottom: 32,
              letterSpacing: "-0.01em",
            }}
          >
            Questions answered.
          </h2>

          <div>
            {faqs.map((faq, i) => (
              <div
                key={i}
                style={{
                  borderTop: "1px solid #E5E5E5",
                  ...(i === faqs.length - 1 ? { borderBottom: "1px solid #E5E5E5" } : {}),
                }}
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  style={{
                    width: "100%",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 16,
                    padding: "20px 0",
                    textAlign: "left",
                    transition: "background-color 150ms",
                  }}
                  aria-expanded={openFaq === i}
                >
                  <span
                    style={{
                      fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif",
                      fontWeight: 500,
                      fontSize: 16,
                      color: "#000000",
                      lineHeight: 1.4,
                    }}
                  >
                    {faq.q}
                  </span>
                  <span style={{ color: "#000000", flexShrink: 0 }}>
                    {openFaq === i ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </span>
                </button>

                {openFaq === i && (
                  <div style={{ paddingBottom: 20 }}>
                    <p
                      style={{
                        fontFamily: "'Lora', Georgia, serif",
                        fontSize: 16,
                        color: "#555555",
                        lineHeight: 1.7,
                      }}
                    >
                      {faq.a}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
