
  # Next - Loyalty Program Prototype

  This is a code bundle for Next - Loyalty Program Prototype. The original project is available at https://www.figma.com/design/Nldz10MFSWIFIEIgj2QN84/Next---Loyalty-Program-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  